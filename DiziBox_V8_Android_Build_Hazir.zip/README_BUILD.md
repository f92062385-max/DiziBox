# DiziBox Android APK / AAB

Bu proje Android derlemesine hazırlandı.

## APK (telefona kurulum için)
Bilgisayarda Node.js kuruluysa:

1. `cd app`
2. `npm install`
3. `npx eas-cli login`
4. `npx eas build:configure`
5. `npx eas build --platform android --profile preview`

Bu profil APK üretir.

## AAB (Google Play için)
`npx eas build --platform android --profile production`

Bu profil AAB üretir.

## Önemli
EAS gerçek APK/AAB dosyasını bulut üzerinde derler ve bunun için Expo/EAS hesabı ile giriş gerekir. Bu sohbet ortamında EAS hesabına erişim veya Android imzalama anahtarı olmadığı için burada sahte bir APK/AAB üretmedim.

Package name:
`com.dizibox.app`

Uygulama adı:
`DiziBox`

Gerçek mağaza sürümünde ayrıca imzalama, gizlilik politikası, içerik lisansları, abonelik sistemi ve gerçek video/CDN bağlantısı tamamlanmalıdır.
